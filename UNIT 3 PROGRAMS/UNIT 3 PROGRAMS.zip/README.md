# UNIT 3 LAB EXERCISE

## Project
Domain-Specific AI Assistant using Embeddings, Semantic Search, FAISS, RAG, LangChain and Groq.

## Run
1. Open this folder in VS Code.
2. Rename `.env.example` to `.env`.
3. Put your Groq API key after `GROQ_API_KEY=`.
4. Open Terminal in this folder.
5. Run:
   pip install -r requirements.txt
6. Run:
   python app.py

The first run downloads the local embedding model. Then ask questions about the supplied document.

## Requirements covered
- Text embeddings
- Semantic similarity search
- FAISS vector database
- RAG document Question Answering
- LangChain chatbot
- Groq-powered AI assistant
- External document retrieval
