import os
from dotenv import load_dotenv
from langchain_core.documents import Document
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_community.vectorstores import FAISS
from langchain_groq import ChatGroq
from langchain.chains import RetrievalQA

load_dotenv()

if not os.getenv("GROQ_API_KEY"):
    raise ValueError("Please put your Groq API key in the .env file.")

# Load text documents
docs = []
folder = "documents"
for name in os.listdir(folder):
    path = os.path.join(folder, name)
    if name.lower().endswith((".txt", ".md")):
        with open(path, "r", encoding="utf-8") as f:
            docs.append(Document(page_content=f.read(), metadata={"source": name}))

if not docs:
    raise ValueError("No documents found in the documents folder.")

# Create embeddings and FAISS vector database
embeddings = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")
db = FAISS.from_documents(docs, embeddings)
db.save_local("faiss_index")

# Groq LLM + RAG
llm = ChatGroq(model="llama-3.1-8b-instant", temperature=0)
qa = RetrievalQA.from_chain_type(
    llm=llm,
    retriever=db.as_retriever(search_kwargs={"k": 3}),
    return_source_documents=True
)

print("\nUNIT 3 LAB EXERCISE - RAG AI ASSISTANT")
print("Semantic Search + FAISS + RAG + Groq")
print("Type 'exit' to stop.\n")

while True:
    question = input("You: ").strip()
    if question.lower() == "exit":
        break
    if not question:
        continue
    result = qa.invoke({"query": question})
    print("\nAssistant:", result["result"])
    sources = {d.metadata.get("source", "unknown") for d in result["source_documents"]}
    print("Sources:", ", ".join(sources), "\n")
