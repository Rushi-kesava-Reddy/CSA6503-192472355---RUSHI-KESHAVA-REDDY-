@echo off
echo Installing required packages...
python -m pip install -r requirements.txt
echo.
echo Starting Unit 3 Lab Exercise...
python app.py
pause
